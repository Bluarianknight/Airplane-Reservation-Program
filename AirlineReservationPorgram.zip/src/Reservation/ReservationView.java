package Reservation;

public interface ReservationView {

}
