package Main;

public class winMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		testWindow x = new testWindow("Test");
		
		x.startWindow();

	}

}
