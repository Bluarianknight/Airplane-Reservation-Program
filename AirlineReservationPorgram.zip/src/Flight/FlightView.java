package Flight;

public interface FlightView {

}
